/* This file is auto generated, version 1 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 SMP Sun May 6 04:01:19 UTC 2012"
#define LINUX_COMPILE_TIME "04:01:19"
#define LINUX_COMPILE_DISTRIBUTION "Debian"
#define LINUX_COMPILE_DISTRIBUTION_OFFICIAL_BUILD
#define LINUX_COMPILE_DISTRIBUTION_UPLOADER "dannf@debian.org"
#define LINUX_COMPILE_DISTRIBUTION_VERSION "2.6.32-45"
#define LINUX_COMPILE_BY "unknown"
#define LINUX_COMPILE_HOST "Debian"
#define LINUX_COMPILER "gcc version 4.3.5 (Debian 4.3.5-4) "
