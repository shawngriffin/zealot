#!/bin/sh
arg=$1

# set -e
. /usr/share/debconf/confmodule

db_get $arg

echo $RET
