#!/usr/bin/perl

#
# log.pl: commonly used routine to keep a logfile.
#

sub log_msg {
    my ($msg) = @_;
    $logfile = "/var/log/localization-config.log";
    open(LOG, ">>$logfile");  # Open for appending
    print LOG $msg."\n";
    close(LOG);
    
    return;
}

sub log_die {
    my ($m) = @_;
    log_msg($m);
    die $m;
}
1;