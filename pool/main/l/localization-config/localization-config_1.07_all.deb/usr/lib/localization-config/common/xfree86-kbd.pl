#!/usr/bin/perl
# Define the XFree86 debconf values for Xkb configuration

use strict;
use warnings;

require '/usr/lib/localization-config/common/x11-kbd.pl';

# We define an associative arrays with the debconf keys
# These will be used in combination with the values in the
# next array
my %keynames = ( XkbLayout     => 'xserver-xfree86/config/inputdevice/keyboard/layout',
                 XkbOptions => 'xserver-xfree86/config/inputdevice/keyboard/options',
                 XkbModel   => 'xserver-xfree86/config/inputdevice/keyboard/model',
                 XkbVariant => 'xserver-xfree86/config/inputdevice/keyboard/variant',
                 XkbRules   => 'xserver-xfree86/config/inputdevice/keyboard/rules'
               );

sub get_keynames() {
    return %keynames;
}

1;
